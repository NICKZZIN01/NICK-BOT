const help = (prefix) => {
	return `👾𝗡𝗜𝗖𝗞𝟭𝟱𝗕𝗢𝗧👾
	
	                
┏━━━°❀ ❬ 𝙎𝙊𝘽𝙍𝙀 ❭ ❀°━━━┓
┃
┏❉ *${prefix}owner*
┣❉ *${prefix}doar*
┗❉ *${prefix}creator*
┃
┣━━━°❀ ❬ 𝘾𝙍𝙄𝘼𝙍 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}sticker* [foto]
┣➥ *${prefix}stickergif* [foto]
┣➥ *${prefix}sticker nobg 
┣➥ *${prefix}thunder* [texto]
┣➥ *${prefix}tsticker* [texto/url]
┃
┣━━━━°❀ ❬ 𝙈𝙄𝘿𝙄𝘼 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}tts* [texto]
┣➥ *${prefix}ocr*
┣➥ *${prefix}loli*
┣➥ *${prefix}toimg*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}wait* [foto]
┣➥ *${prefix}simi
┣➥ *${prefix}simih*
┣➥ *${prefix}wait*
┃
┣━━━━°❀ ❬ 𝙂𝙍𝙐𝙋𝙊 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}setname*
┣➥ *${prefix}setdesc*
┣➥ *${prefix}getpp*
┣➥ *${prefix}tagall*
┣➥ *${prefix}linkgroup
┣➥ *${prefix}gprofile*
┣➥ *${prefix}setprefix
┣➥ *${prefix}welcome*
┣➥ *${prefix}left*
┃
┣━━━━°❀ ❬ 𝙎𝙊𝙉𝙎 ❭ ❀°━━━━━⊱
┃
┣➥ *salam*
┣➥ *tariksis*
┣➥ *baka*
┣➥ *desah*
┣➥ *goblok*
┣➥ *roti*
┣➥ *welot*
┣➥ *abangjago*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃
┃╔══╗╔═╗╔══╗╔══╗
┃║╔╗║║╬║╚║║╝║══╣
┃║╠╣║║╗╣╔║║╗╠══║
┃╚╝╚╝╚╩╝╚══╝╚══╝
┃───────────────
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ 𝗙𝗘𝗜𝗧𝗢 𝗣𝗢𝗥  ⃬⃗𝑵𝑰𝑪𝑲  ☔
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.help = help

