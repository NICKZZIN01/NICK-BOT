const help1 = (prefix) => {

	return `
╔══✪〘 INFO 〙✪══
║
╠➥ 𝑵𝑰𝑪𝑲 𝑩𝑶𝑻
╠➥ *3.0*
╠➥ 𝐃𝐎𝐍𝐎:  ⃬⃗𝑵𝑰𝑪𝑲  ☔
╠➥ *wa.me/+5512997277680*
╠➥ 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══✪〘 MENU1 〙✪══
║
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
╠➥ *${prefix}*
║
╠══✪〘 *FIM* 〙✪══

════════════════════
*NICKZZIN YT* 🤗
*Digite ${prefix}dono para mais info*
════════════════════`
}
exports.help1 = help1

